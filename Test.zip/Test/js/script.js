/*header js start*/
(function($) { "use strict";

	$(function() {
		var header = $(".start-style");
		$(window).scroll(function() {    
			var scroll = $(window).scrollTop();
		
			if (scroll >= 10) {
				header.removeClass('start-style').addClass("scroll-on");
			} else {
				header.removeClass("scroll-on").addClass('start-style');
			}
		});
	});		
		
	
	$(document).ready(function() {
		$('body.hero-anime').removeClass('hero-anime');
	});

	
	$('body').on('mouseenter mouseleave','.nav-item',function(e){
			if ($(window).width() > 750) {
				var _d=$(e.target).closest('.nav-item');_d.addClass('show');
				setTimeout(function(){
				_d[_d.is(':hover')?'addClass':'removeClass']('show');
				},1);
			}
	});	
	
	
	$("#switch").on('click', function () {
		if ($("body").hasClass("dark")) {
			$("body").removeClass("dark");
			$("#switch").removeClass("switched");
		}
		else {
			$("body").addClass("dark");
			$("#switch").addClass("switched");
		}
	});  
	
  })(jQuery);
  
/*header js end*/
  
/*company logo slider js start*/  
   
  $('.autoplay-slider').slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000, 
    speed: 800 ,
	 responsive: [
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
        dots: false,
        arrows:false
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1
      }
    }   
  ]
  });
  
/*company logo slider js end*/  

/*pricing plan js start*/

function monthly() {
  
  //Background for yearly button back to blue 
  document.getElementById("yearly").style.background = "#0b1a33";
  //Background for monthly button back to pink
  document.getElementById("monthly").style.background = "#bc2e3c";
  
  //Change to monthly prices
  document.getElementById("wordpress").innerHTML = "$20/mo.";
  document.getElementById("shared").innerHTML = "$20/mo.";
  document.getElementById("vps").innerHTML = "$30/mo.";
}

function yearly() {
  
  //Background for yearly button back to blue
  document.getElementById("monthly").style.background = "#0b1a33";
  //Background for monthly button back to pink
  document.getElementById("yearly").style.background = "#bc2e3c";
  
  //Change to monthly prices
  document.getElementById("wordpress").innerHTML = "$216/yr.";
  document.getElementById("shared").innerHTML = "$216/yr.";
  document.getElementById("vps").innerHTML = "$324/yr.";
}

/*pricing plan js end*/

/*testimonial slider js start*/
    if ($(".ts-testimonial-slide").length > 0) {
    
        $(".ts-testimonial-slide").owlCarousel({
            autoPlay: 4000,
            slideSpeed: 1000,
            navigation: false,
            pagination: true,
            singleItem: true
        });
    };
	
/*testimonial slider js end*/


/*smooth scroll js start*/

$(document).ready(function(){
	$('a[href^="#"]').on('click',function (e) {
	    e.preventDefault();
	    var target = this.hash;
	    var $target = $(target);
	    $('html, body').stop().animate({
	        'scrollTop': $target.offset().top
	    }, 900, 'swing', function () {	        
	    });
	});
});

/*smooth scroll js end*/

/*animation js start*/

AOS.init({
  duration: 1200,
});

/*animation js end*/










